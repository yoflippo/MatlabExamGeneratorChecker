Elk element van een vector heeft een index. Deze index kan 
worden gebruikt om de waarde van het element op te vragen.