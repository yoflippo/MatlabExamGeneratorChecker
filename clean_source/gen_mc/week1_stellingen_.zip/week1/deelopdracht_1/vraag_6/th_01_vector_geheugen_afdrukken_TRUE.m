Zodra een vector in het geheugen staat, kan de vector in
zijn geheel worden afgedrukt in het Command Window 
door het typen van de naam van deze vector in het 
Command Window