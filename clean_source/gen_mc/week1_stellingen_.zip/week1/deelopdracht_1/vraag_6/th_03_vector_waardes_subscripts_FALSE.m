De variabele 'vec' heeft de waardes '2 3 4 3 4 5 6' na
het uitvoeren van de volgende code:

------------code--------------
vector = 3:13;
vec = vector([1:3 2:5]);
------------code--------------