Met behulp van de colon operator kan een numerieke
vector worden aangemaakt.