Met behulp van de colon operator kan een willekeurige
vector worden aangemaakt.