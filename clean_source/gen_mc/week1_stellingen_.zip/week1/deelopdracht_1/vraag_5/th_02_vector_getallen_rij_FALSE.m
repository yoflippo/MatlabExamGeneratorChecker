Een vector kan alleen getallen bevatten. Deze getallen
staan in een rij.