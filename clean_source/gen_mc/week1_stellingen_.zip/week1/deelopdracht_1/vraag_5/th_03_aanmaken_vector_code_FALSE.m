De onderstaande code maakt een numerieke vector aan (een 
vector bestaande uit getallen) met een lengte van 10:

------------code--------------
vec = 0:10;
------------code--------------