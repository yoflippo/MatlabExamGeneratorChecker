Bij het uitvoeren van de volgende code is het resultaat
in de Command Window: ' ans = 
                             'a'
                      '
                      
------------code--------------
naam = 'Mark Schrauwen';
naam(2)
------------code--------------
