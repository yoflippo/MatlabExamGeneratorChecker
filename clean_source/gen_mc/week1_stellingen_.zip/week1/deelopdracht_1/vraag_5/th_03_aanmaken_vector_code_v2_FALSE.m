De onderstaande code maakt een numerieke vector aan (een 
vector bestaande uit getallen) met een lengte van 11:

------------code--------------
vec = 1:10;
------------code--------------