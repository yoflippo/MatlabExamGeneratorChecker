In de volgende code wordt alleen bij ��n element
van de vector de waarde 99 opgeteld:

------------code--------------
vector = 0:10;
vector = vector + (100 - 1);
------------code--------------