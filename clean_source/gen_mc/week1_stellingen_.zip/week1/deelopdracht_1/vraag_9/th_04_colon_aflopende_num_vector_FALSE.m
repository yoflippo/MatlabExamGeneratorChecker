Met de colon-operator kan een aflopende numerieke
vector worden aangemaakt.