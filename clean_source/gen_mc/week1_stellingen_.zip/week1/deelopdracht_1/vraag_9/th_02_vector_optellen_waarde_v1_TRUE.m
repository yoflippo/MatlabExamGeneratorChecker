In de volgende code wordt er bij elk element van de vector
de waarde 99 opgeteld:

------------code--------------
vector = 0:10;
vector = vector + (100 - 1);
------------code--------------