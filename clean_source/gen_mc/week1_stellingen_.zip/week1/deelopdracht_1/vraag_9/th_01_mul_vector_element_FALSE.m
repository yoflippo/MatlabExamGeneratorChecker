In de onderstaande code worden twee vectoren element-by-element
met elkaar vermenigvuldigd:

------------code--------------
vector = 0:10;
vector2 = 1:11;
vector * vector2;
------------code--------------