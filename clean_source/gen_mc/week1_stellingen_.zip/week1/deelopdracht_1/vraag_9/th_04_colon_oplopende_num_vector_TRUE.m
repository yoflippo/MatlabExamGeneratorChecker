Met de colon-operator kan een oplopende numerieke
vector worden aangemaakt.