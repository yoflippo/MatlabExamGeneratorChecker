De naam van een script mag beginnen met een willekeurig
symbool