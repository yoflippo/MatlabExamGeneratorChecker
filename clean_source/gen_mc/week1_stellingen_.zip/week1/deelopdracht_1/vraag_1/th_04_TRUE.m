De naam van een script mag niet beginnen met een 
willekeurig symbool