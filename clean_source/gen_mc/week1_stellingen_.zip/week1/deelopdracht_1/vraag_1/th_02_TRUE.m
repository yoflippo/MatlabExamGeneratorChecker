In de Workspace staan de variabelen die Matlab heeft
gebruikt na het uitvoeren van een programma.