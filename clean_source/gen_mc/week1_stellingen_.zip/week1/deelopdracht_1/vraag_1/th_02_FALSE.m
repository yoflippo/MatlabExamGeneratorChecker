In de Workspace staan de bestanden van de huidige folder (de
folder waaruit Matlab werkt)