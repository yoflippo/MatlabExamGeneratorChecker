Matlab is alleen een programmeertaal en is niet een 
programmeeromgeving.