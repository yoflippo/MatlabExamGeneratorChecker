In de volgende code wordt alleen bij het laatste element 
van de vector de waarde 78 opgeteld:

------------code--------------
vector = 22:33;
vector = vector + 78;
------------code--------------