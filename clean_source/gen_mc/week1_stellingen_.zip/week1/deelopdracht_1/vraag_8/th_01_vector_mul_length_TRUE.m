Bij het uitvoeren van de onderstaande code wordt de 
vector drie keer zo lang:

------------code--------------
vector = 22:44;
vector * 3;
------------code--------------