In de volgende code wordt alleen de waarde van het eerste 
element drie keer zo groot.

------------code--------------
vector = 22:44;
vector * 3;
------------code--------------