Met de functie sqrt() kan de worteltrek operatie worden 
uitgevoerd.