In de volgende code regel heeft de min-operator 
voorrang op de macht-operator: 76 � 6^2.