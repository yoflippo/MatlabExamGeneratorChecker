Een operator voert een handeling uit op ��n of meerdere
operands.