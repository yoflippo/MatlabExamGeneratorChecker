In Matlab kan machtverheffing met de volgende operator 
worden uitgevoerd: ^