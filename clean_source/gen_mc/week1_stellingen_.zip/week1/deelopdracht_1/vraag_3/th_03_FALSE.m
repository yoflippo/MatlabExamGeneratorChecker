In het Command Window kun je niet zelf opdrachten/commandos
uitvoeren.