Het voordeel van het gebruik van variabelen in een 
programma is het programma sneller werkt.