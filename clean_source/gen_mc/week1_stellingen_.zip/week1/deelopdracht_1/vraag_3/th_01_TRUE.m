In Matlab laat de Current Folder zien in welke folder Matlab
op dit moment aan het werken.