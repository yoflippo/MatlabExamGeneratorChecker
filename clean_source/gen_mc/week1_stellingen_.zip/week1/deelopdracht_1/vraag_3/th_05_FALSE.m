De naam van een variabele in Matlab moet zo kort mogelijk 
zijn