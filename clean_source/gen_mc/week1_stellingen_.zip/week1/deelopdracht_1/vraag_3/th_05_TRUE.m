Een stuk tekst (string) kan op de volgende manier aan
een variabele worden toegekend: var = 'tekst'