De script editor wordt alleen zichtbaar als een script is
geopend.