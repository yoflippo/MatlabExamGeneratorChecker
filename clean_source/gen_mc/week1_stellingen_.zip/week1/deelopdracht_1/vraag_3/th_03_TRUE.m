Variabelen in Matlab mogen alleen beginnen met 
alfanumerieke symbolen