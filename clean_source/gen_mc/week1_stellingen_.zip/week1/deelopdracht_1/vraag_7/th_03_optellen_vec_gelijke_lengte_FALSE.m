Je kunt in Matlab elke willekeurige vector optellen bij
een andere willekeurige vector.