Het aanmaken van een numerieke vector kan voor een
Bewegingstechnoloog handig zijn om bijvoorbeeld een 
tijd vector aan te maken. Dat is een tijdvector 
bestaande uit tijdstippen.