Het aanmaken van een numerieke vector is voor een
Bewegingstechnoloog zelden handig.