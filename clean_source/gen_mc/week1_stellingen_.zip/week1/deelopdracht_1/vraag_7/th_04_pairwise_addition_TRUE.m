Als je in Matlab vectoren bij elkaar optelt dan wordt
dit 'pair-wise addition' genoemd.