In de onderstaande code worden de laatste vier elementen
van een vector afgedrukt:

------------code--------------
vector = 2:66;
vector(end-4:end)
------------code--------------