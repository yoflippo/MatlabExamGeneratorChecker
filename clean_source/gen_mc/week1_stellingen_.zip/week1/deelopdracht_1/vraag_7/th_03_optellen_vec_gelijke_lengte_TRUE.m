Bij het optellen van vectoren in Matlab moet een programmeur
opletten dat de vectoren een gelijke lengte hebben.