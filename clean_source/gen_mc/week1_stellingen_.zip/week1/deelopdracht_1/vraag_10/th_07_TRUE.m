Om de output van een script te beperken plaatsen we aan het
einde van een regel een ;  (puntkomma) 