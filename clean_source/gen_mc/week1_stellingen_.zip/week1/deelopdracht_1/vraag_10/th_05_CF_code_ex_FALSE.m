In de Current Folder kan een gebruiker code typen en
uitvoeren.