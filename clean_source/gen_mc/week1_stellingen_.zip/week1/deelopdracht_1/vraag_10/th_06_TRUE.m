Het resultaat van een regel code uit een script kan, na 
het uitvoeren van de regel code, te zien zijn in het
Command Window