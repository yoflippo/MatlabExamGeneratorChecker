Het resultaat van een regel code uit een script is na
het uitvoeren van die regel nooit te zien in het 
Command Window