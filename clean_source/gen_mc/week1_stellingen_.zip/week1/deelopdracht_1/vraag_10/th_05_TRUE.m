In de Command Prompt kan een gebruiker code typen en
uitvoeren.