Bij het aan elkaar maken van meerdere strings m.b.v. 
rechte haken wordt er niet automatisch een spatie geplaats
tussen de afzonderlijke strings. Bijvoorbeeld: ['Bio' 'statica']