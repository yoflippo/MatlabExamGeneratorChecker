Met de rechte haken [ en ] kun je in Matlab verschillende
strings aan elkaar maken.