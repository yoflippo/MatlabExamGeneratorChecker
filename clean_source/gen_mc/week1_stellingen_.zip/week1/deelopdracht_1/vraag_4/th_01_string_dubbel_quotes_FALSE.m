Het maakt niet uit of je een string aanmaakt met enkele
quotes of dubbele quotes. Voorbeeld: "tekst" of 'tekst'.