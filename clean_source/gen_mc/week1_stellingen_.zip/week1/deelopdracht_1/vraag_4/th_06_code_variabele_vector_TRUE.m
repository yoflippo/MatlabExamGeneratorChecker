Bij het uitvoeren van de onderstaande code is de variabele
'naam' een vector.
                      
------------code--------------
naam = 'Mark Schrauwen';
naam(3)
------------code--------------