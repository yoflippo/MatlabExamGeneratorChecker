Bij het uitvoeren van de onderstaande code is de variabele
'naam' een string.
                      
------------code--------------
naam = 'Mark Schrauwen';
naam(3)
------------code--------------