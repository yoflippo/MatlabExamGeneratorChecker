De volgende code wordt in Matlab correct uitgevoerd:

------------code--------------
voornaam = 'Mark'
achternaam = 'Hark'
volledigeNaam = voornaam + achternaam
------------code--------------