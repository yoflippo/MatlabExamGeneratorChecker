De volgende code wordt in Matlab correct uitgevoerd:

------------code--------------
voornaam = 'Mark'
achternaam = 'Schrauwen'
volledigeNaam = voornaam + achternaam
------------code--------------