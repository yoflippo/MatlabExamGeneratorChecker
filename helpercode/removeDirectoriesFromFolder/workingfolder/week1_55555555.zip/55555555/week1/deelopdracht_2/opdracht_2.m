%% ==================== BLIJF VAN DE VOLGENDE CODE AF! ====================
%                    |a8a75ac4c6810b9b90d4f7285fb9e1f0|
% Alles wat je nodig hebt om deze opdracht te doen, staat in dit bestand!
%
% LEES EN BEGRIJP DE VOLGENDE REGELS:
%
% 1 - De volgende door ons aangemaakte zaken mag jij NIET aanpassen!:
%                           A: bestandsnamen
%                           B: door ons aangemaakte commentaar
%                           C: folders en folderstructuur
%                           D: de code in deze codesectie
%     Pas je toch iets aan dan krijg je GEEN punten voor deze weekopdracht.
% 2 - Als het script niet uit te voeren valt, krijg je GEEN punten!
% 3 - Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 - Je mag geen aparte scripts/functies gebruiken ten zij dit expliciet
%     is aangegeven
% 
% Opdrachtbeschrijving
% Deze opdracht bestaat uit het schrijven/aanvullen van een script. De
% specifieke opdracht staat hieronder.
%% =================== BLIJF VAN VOORGAANDE CODE AF! ======================
%
%% Opdracht 1
% Maak een variabele aan met de naam: ikbeneenvariabele.
% Geef de variabele de waarde 22
