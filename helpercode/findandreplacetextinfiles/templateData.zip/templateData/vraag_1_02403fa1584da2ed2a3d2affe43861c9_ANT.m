%% Vraag 1
% Stelling 1: Matlab is een programmeeromgeving en een programmeertaal
% Stelling 2: In de workspace staan de bestanden van de huidige folder (de
% folder waaruit Matlab werkt)
%
% A : stelling 1 is WAAR      en stelling 2 is NIET-WAAR
% B : stelling 1 is NIET-WAAR en stelling 2 is WAAR
% C : stelling 1 is NIET-WAAR en stelling 2 is NIET-WAAR
% D : stelling 1 is WAAR      en stelling 2 is WAAR
Antwoord_Vraag1 = A; % vul hier het juiste antwoord in A, B, C of D
