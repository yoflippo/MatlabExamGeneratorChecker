%% ==================== BLIJF VAN DE VOLGENDE CODE AF! ====================
%                    |137b9a80a5faed5102a50008a69015be|
%
% LEES EN BEGRIJP DE VOLGENDE REGELS:
%
% 1 - De volgende door ons aangemaakte zaken mag jij NIET aanpassen!:
%                           A: bestandsnamen
%                           B: door ons aangemaakt commentaar
%                           C: folders en folderstructuur
%                           D: de code in deze codesectie
%     Pas je toch iets aan dan krijg je GEEN punten voor deze weekopdracht.
% 2 - Als het script niet uit te voeren valt, krijg je GEEN punten!
% 3 - Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 - Je mag geen aparte scripts/functies gebruiken tenzij dit expliciet
%     is aangegeven
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een script. De
% specifieke opdracht staat hieronder.
% =================== BLIJF VAN VOORGAANDE CODE AF! ======================
 
%% Opdracht 7
% Gegeven onderstaande script met een bijzondere vector.
% Vraag m.b.v. een standaard Matlab functie de afmetingen op van de
% vector 'matx'. 
% Deze functie geeft het aantal rijen en kolommen terug van de variabele.
% Stop vervolgens de het aantal rijen in de variabele: 'rijn' en
% stop daarna het aantal kolommen in de variabele 'koln'.
       
matx = [3 5 6 7 8 5 4 5; 
        5 4 5 8 7 6 5 3; 
        3 2 3 6 5 4 3 1;];
    
    size(matx)
    
koln = 8;
rijn = 3;
