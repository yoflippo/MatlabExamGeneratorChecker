opdracht_1(5)
