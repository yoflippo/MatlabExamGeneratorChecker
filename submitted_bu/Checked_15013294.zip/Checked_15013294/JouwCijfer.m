%Jouw cijfer: 5.6
% Kijk in elk m-file voor jouw score
% Kijk eventueel in het ANTWOORD bestand om te zien wat er
% fout is gegaan.
% Let goed op exacte naamgeving. De variabele "a" 
% is ongelijk aan de variabele "A". 
