%% ==================== BLIJF VAN DE VOLGENDE CODE AF! ====================
%                    |feb4f72a6983cc6bdb47ca95c037f309|
%
% LEES EN BEGRIJP DE VOLGENDE REGELS:
%
% 1 - De volgende door ons aangemaakte zaken mag jij NIET aanpassen!:
%                           A: bestandsnamen
%                           B: door ons aangemaakt commentaar
%                           C: folders en folderstructuur
%                           D: de code in deze codesectie
%     Pas je toch iets aan dan krijg je GEEN punten voor deze weekopdracht.
% 2 - Als het script niet uit te voeren valt, krijg je GEEN punten!
% 3 - Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 - Je mag geen aparte scripts/functies gebruiken tenzij dit expliciet
%     is aangegeven
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een script. De
% specifieke opdracht staat hieronder.
% =================== BLIJF VAN VOORGAANDE CODE AF! ======================
 
%% Opdracht 5
% Maak een vector genaamd 'tijdas' aan.
% Zorg dat de vector wordt gevuld met de tijd van 0 tot en met 60 seconden.
% Zorg dat de vector met tijdstappen van 0.1 seconde wordt gevuld.
% VB: 0, 0.1, 0.2, 0.3 ...

tijdas = [0:0.1:60];
 
%% Opmerkingen tijdens nakijken 
 
% Jij hebt deze opdracht 100% goed gemaakt.
%% Opmerkingen tijdens nakijken 
 
