%% ==================== BLIJF VAN DE VOLGENDE CODE AF! ====================
%                    |c86fd4447240eed5954db40c4635c284|
%
% LEES EN BEGRIJP DE VOLGENDE REGELS:
%
% 1 - De volgende door ons aangemaakte zaken mag jij NIET aanpassen!:
%                           A: bestandsnamen
%                           B: door ons aangemaakt commentaar
%                           C: folders en folderstructuur
%                           D: de code in deze codesectie
%     Pas je toch iets aan dan krijg je GEEN punten voor deze weekopdracht.
% 2 - Als het script niet uit te voeren valt, krijg je GEEN punten!
% 3 - Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 - Je mag geen aparte scripts/functies gebruiken tenzij dit expliciet
%     is aangegeven
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een script. De
% specifieke opdracht staat hieronder.
% =================== BLIJF VAN VOORGAANDE CODE AF! ======================
 
%% Opdracht 1
% Gegeven is onderstaande code. Tel bij de vector 'getallen'
% de waarde 1 op en stop het resultaat in de output variabele 'plus1'.
% 
% Trek van de vector 'getallen' de waarde 1 af en stop het resultaat
% van die handeling in de output variabele min1.
%
% Deze functie moet jezelf aanroepen m.b.v. een extra script.
% Dat script moet jezelf maken en mag je  in dezelfde folder zetten als dit 
% bestand. Dat script wordt niet nagekeken of gebruikt door ons.

function [plus1 min1] = opdracht1(getallen)
plus1 = getallen+1
min1 = getallen-1

end
 
%% Opmerkingen tijdens nakijken 
 
% Jij hebt deze opdracht 100% goed gemaakt.
%% Opmerkingen tijdens nakijken 
 
