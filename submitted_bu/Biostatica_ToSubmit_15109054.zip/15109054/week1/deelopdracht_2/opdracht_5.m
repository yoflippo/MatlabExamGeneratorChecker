%% ==================== BLIJF VAN DE VOLGENDE CODE AF! ====================
%                    |a2bd7893f6e07e8178cbb3a5e9b7ee08|
%
% LEES EN BEGRIJP DE VOLGENDE REGELS:
%
% 1 - De volgende door ons aangemaakte zaken mag jij NIET aanpassen!:
%                           A: bestandsnamen
%                           B: door ons aangemaakt commentaar
%                           C: folders en folderstructuur
%                           D: de code in deze codesectie
%     Pas je toch iets aan dan krijg je GEEN punten voor deze weekopdracht.
% 2 - Als het script niet uit te voeren valt, krijg je GEEN punten!
% 3 - Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 - Je mag geen aparte scripts/functies gebruiken tenzij dit expliciet
%     is aangegeven
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een script. De
% specifieke opdracht staat hieronder.
% =================== BLIJF VAN VOORGAANDE CODE AF! ======================
 
%% Opdracht 5
% Maak een vector genaamd 'tijdas' aan.
% Zorg dat de vector wordt gevuld met de tijd van 0 tot en met 100 seconden.
% Zorg dat de vector met tijdstappen van 0.25 seconde wordt gevuld.
% VB: 0, 0.25, 0.5, 0.75, 1.0, 1.25...
tijdas = 0:0.25:100;

