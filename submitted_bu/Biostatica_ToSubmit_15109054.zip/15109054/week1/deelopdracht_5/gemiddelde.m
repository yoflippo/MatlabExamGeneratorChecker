function resultaat = gemiddelde(~)
getallen = 5:25;
gemiddeldeVector = mean(getallen)
end


